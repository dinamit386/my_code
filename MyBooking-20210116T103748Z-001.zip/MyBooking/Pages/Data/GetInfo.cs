﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyBooking.Pages.Data
{
    public class GetInfo
    {
        public int id { get; set; }
        public int Make { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }
        public string Model { get; set; }
    }
}
