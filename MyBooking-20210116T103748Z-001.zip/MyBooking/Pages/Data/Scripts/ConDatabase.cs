﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore;
using System.Data;
using System.Configuration;

namespace MyBooking.Pages.Data.Scripts
{
    public class ConDatabase
     {
        public static void SqlCon()
        {
            string conString = "Data Source = LP0019165 / SQLEXPRESS; Initial Catalog = Transport; Integrated Security = True;";

            SqlConnection sqlCon = new SqlConnection(conString);

            /*
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = conString;

                connection.Open();
            }
            */
        }
       
    }
    public class CarHireInfo
    {
        public int id { get; set; }
        public string carModel { get; set; }
        public string carMake { get; set; }
        public float carPrice { get; set; }
        public int carYear { get; set; }
    }

}
